#include "main.h"
// Noi khai bao hang so
#define     LED     PORTA
#define     ON      1
#define     OFF     0
#include <string.h>
#include <stdio.h>

// Noi khai bao bien toan cuc
unsigned char arrayMapOfOutput [8] = {0x01,0x02,0x04,0x08,0x10,0x20,0x40,0x80};
unsigned char statusOutput[8] = {0,0,0,0,0,0,0,0};
// Khai bao cac ham co ban IO
void init_system(void);
void delay_ms(int value);
void OpenOutput(int index);
void CloseOutput(int index);
void TestOutput(void);
void ReverseOutput(int index);
//Bai tap chong rung nut nhan
char numberOfPushButton = 0;
unsigned char isButtonUp();
unsigned char isButtonMotorDown();
void BaiTap_ChongRung();

int time_c=0;
 int red_time = 5;
 int green_time = 3;
 int yellow_time = 2;
void Test_KeyMatrix();
////////////////////////////////////////////////////////////////////
//Hien thuc cac chuong trinh con, ham, module, function duoi cho nay
////////////////////////////////////////////////////////////////////
void main(void)
{
	unsigned int k = 0;
	init_system();

    PORTA=~0b100001;
	while (1)
	{    
         while (!flag_timer3);
            flag_timer3 = 0;
        scan_key_matrix();
        
        TestOutput();
	}
}
// Hien thuc cac module co ban cua chuong trinh
void delay_ms(int value)
{
	int i,j;
	for(i=0;i<value;i++)
		for(j=0;j<238;j++);
}

void init_system(void)
{
    TRISB = 0x00;		//setup PORTB is output
    TRISD = 0x00;
    TRISA = 0x00; // SU DUNG PORT A
    init_lcd();
    LcdClearS();
    //LED = 0x00;
    init_interrupt();
    init_timer0(4695);//dinh thoi 1ms sai so 1%
    init_timer1(9390);//dinh thoi 2ms
    init_timer3(46950);//dinh thoi 10ms
    SetTimer0_ms(1000);
    SetTimer1_ms(3000);//TIME RED_GREEN KHI INIT
    SetTimer3_ms(50); //Chu ky thuc hien viec xu ly input,proccess,output
    init_key_matrix();
}

void OpenOutput(int index)
{
	if (index >= 0 && index <= 7)
	{
		LED = LED | arrayMapOfOutput[index];
	}

}

void CloseOutput(int index)
{
	if (index >= 0 && index <= 7)
	{
		LED = LED & ~arrayMapOfOutput[index];
	}
}

void ReverseOutput(int index)
{
    if (statusOutput[index]  == ON)
    {
        CloseOutput(index);
        statusOutput[index] = OFF;
    }
    else
    {
        OpenOutput(index);
        statusOutput[index] = ON;
    }
}


enum State{red_green,red_yellow,green_red,yellow_red};
enum State state=red_green;

void TestOutput(void)
{
      char *str = "                ";
        switch (state)
        {
            case red_green: {
           
                if (flag_timer0)
                {
                    // puts string into buffer
                    time_c++;
                    LcdPrintString(0,0,"Mode 1 DO XANH");
                    LcdPrintString(1,0,str);

                    
                    flag_timer0=0;
                    if (time_c==3)
                    {
                    PORTA=~0b010001;
                    state=red_yellow;
                    time_c=0;
                    }
                }
                    break;
            }
            case red_yellow: {
             
                if (flag_timer0)
                {
                    time_c++;
                     LcdPrintString(0,0,"Mode 1 DO VANG");
                    LcdPrintString(1,0,str);
                    flag_timer0=0;
                     if (time_c==2)
                    {
                    PORTA=~0b001100;
                    state=green_red;
                    time_c=0;
                     }
                }
                    break;
            }
            
             case green_red: {
              
                if (flag_timer0)
                {
                     time_c++;
                     
                                       LcdPrintString(0,0,"Mode 1 XANH DO");
                    str[7]=5-time_c+48;
                    LcdPrintString(1,0,str);
                    flag_timer0=0;
                      if (time_c==3)
                    {
                    PORTA=~0b001010;
                    state=yellow_red;
                    time_c=0;
                     }
                }
                    break;
            }
             
              case yellow_red: {
          
                if (flag_timer0)
                {
                     time_c++;
                     
                                     LcdPrintString(0,0,"Mode 1 VANG DO");
                    str[7]=5-time_c+48;
                    LcdPrintString(1,0,str);
                    flag_timer0=0;
                      if (time_c==2)
                    {
                    PORTA=~0b100001;
                    state=red_green;
                    time_c=0;
                    }
                }
                    break;
            }
        }
}

unsigned char isButtonUp()
{
    if (key_code[0] == 1 || (key_code[0] >= 10 && key_code[0]%2 == 1))
        return 1;
    else
        return 0;
}
unsigned char isButtonDown()
{
    if (key_code[1] == 1)
        return 1;
    else
        return 0;
}
void BaiTap_ChongRung()
{
    if (isButtonUp())
        numberOfPushButton ++;
    if (isButtonDown())
        numberOfPushButton --;
    LcdPrintStringS(0,0,"    ");
    LcdPrintNumS(0,0,numberOfPushButton);
}

void Test_KeyMatrix()
{
    int temp_i;
    for (temp_i=0; temp_i<=15; temp_i++)
    {
        if(key_code[temp_i] != 0)
            LcdPrintStringS(1,temp_i,"_");
        else
            LcdPrintStringS(1,temp_i," ");
    }
}